/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IndiefyLogin;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.label;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.sql.ResultSet;
/**
 *
 * @author jacob
 */
public class LoginScreenController {

    @FXML
    private TextField username;
    
    @FXML
    private PasswordField password;
    
    @FXML
    private Label output;
    
    @FXML
    private Button next;
    
    Database d = new Database();
    
    
    //Initiate JavaFX nodes (visual elements), how do we connect these variables to the FXML view?

    // Initiate the database class

    /* What should happen when you click the login button?
       How do we connect this function to the FXML view? */
    
    @FXML
    private void handleLoginButtonAction(ActionEvent event) {
        
        // Get the user's input from the GUI

        String user = username.getText();
        String pass = password.getText();
        
        
        
        //if (d.tryLogin(user, pass)) {
        
        if (user == "Pretentious" && pass == "Hipster")
          output.setText("Login Successful");
        //} else {
          output.setText("Incorrect Username or Password, Please Try Again");
        }
        
    }

    @FXML
    public void initialize() {
       //What should the user see when the screen loads?
        System.out.println("calling init");
        output.setVisible(false);
        next.setVisible(false);
        
    }

}
