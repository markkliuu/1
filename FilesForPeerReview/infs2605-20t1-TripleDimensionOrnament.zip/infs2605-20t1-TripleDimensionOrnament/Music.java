/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IndiefyLogin;


import javafx.beans.property.StringProperty; 
import javafx.beans.property.SimpleStringProperty;
/**
 *
 * @author thaihuynh
 */
public class Music {
    
    private StringProperty album;
    private StringProperty artist;
    private StringProperty genre;
    private StringProperty year;
   // Add the other attributes for the Music List
    
    public Music() {
        this("","","","");
    }

    public Music(String album, String artist, String genre, String year) {
        this.album = new SimpleStringProperty(album);
        this.artist = new SimpleStringProperty(artist);
        this.genre = new SimpleStringProperty(genre);
        this.year = new SimpleStringProperty(year);
        // Complete the constructor
    }
    
   
   // Add getters for String Properties

    public StringProperty getAlbum() {
        return album;
    }

    public StringProperty getArtist() {
        return artist;
    }

    public StringProperty getGenre() {
        return genre;
    }

    public StringProperty getYear() {
        return year;
    }
    
    
    
}
