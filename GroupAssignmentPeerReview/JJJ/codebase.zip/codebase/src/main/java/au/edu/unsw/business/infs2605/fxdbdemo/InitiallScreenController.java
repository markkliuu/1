/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.fxdbdemo;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

/**
 *
 * @author Leo
 */
public class InitiallScreenController {
    
@FXML 
private Button AdminLogin;

@FXML 
private Button GuestLogin;

@FXML
private Button BtSignUp;

@FXML
private Button btSecondary;

@FXML
    private void switchToAdminLogin() throws IOException {
        App.setRoot("AdminLogin");
    }

@FXML
    private void switchToGuestLogin() throws IOException {
        App.setRoot("GuestLogin");
    }    

    @FXML
    private void SignUp() throws IOException {
        App.setRoot("SignUp");
    }
    
    @FXML
    private void secondary() throws IOException {
        App.setRoot("secondary");
    }
}
