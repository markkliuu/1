/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.fxdbdemo;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

/**
 *
 * @author Leo
 */
public class AdminRSVPController {
    @FXML
    private Button btGuests;
    
    @FXML
    private Button btEvents;
    
    @FXML
    private Button btProfile;
    
    @FXML 
    private Button btAbout;
    
    @FXML 
    private Button btDash;
    
    @FXML
    private void About() throws IOException {
        App.setRoot("About");
    }
    
    @FXML
    private void Guests() throws IOException {
        App.setRoot("AdminGuests");
    }
    
    @FXML
    private void Events() throws IOException {
        App.setRoot("AdminEvents");
    }
    
    @FXML
    private void Profile() throws IOException {
        App.setRoot("AdminProfile");
    }
    
    @FXML
    private void Dash() throws IOException {
        App.setRoot("AdminDashboard");
    }
}
