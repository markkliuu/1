/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.fxdbdemo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


public class DatabaseForAdmin {
    private static ObservableList<Admin> adminLogin = FXCollections.observableArrayList();
    private static final String TABLE_NAME_FOR_ADMIN = "admin";
    private static Connection sharedConnection;
    

    public static void populateInMemoryData() {
        ArrayList<Admin> admin = DatabaseForAdmin.showAdminLogin();
        adminLogin = FXCollections.observableArrayList(admin);
    }
    
    public static ObservableList<Admin> getCurrentAdminData() {
        return DatabaseForAdmin.adminLogin;
    }
    
    /**
     * This method is shared by all the `public static` methods in this class, to reuse the same code.
     * @return whether or not the connection was successfully opened
     */
    private static boolean openConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            DatabaseForAdmin.sharedConnection = DriverManager.getConnection("jdbc:sqlite:Users.db");
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean closeConnection() {
        boolean wasThisMethodSuccessful = false;
        try {
            sharedConnection.close();
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean createAdminTable() {
        boolean wasThisMethodSuccessful = false;
        try {
            DatabaseForAdmin.openConnection();
            String createTableSql = "CREATE TABLE " + DatabaseForAdmin.TABLE_NAME_FOR_ADMIN + " ("
                    + "admin_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + "username TEXT, "
                    + "password TEXT)";
            Statement smt = sharedConnection.createStatement();
            wasThisMethodSuccessful = smt.execute(createTableSql);
            DatabaseForAdmin.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    private static boolean setupDummyData() {
        boolean wasThisMethodSuccessful = false;
        try {
            DatabaseForAdmin.openConnection();
            String sqlString = "INSERT INTO " + DatabaseForAdmin.TABLE_NAME_FOR_ADMIN
                    + " (username, password)"
                    + " VALUES (?, ?)";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            String[] usernames = {"Bob", "Matt", "Josh"};
            String[] password = {"bob", "matt", "josh"};
            for (int i = 0; i < usernames.length; i++) {
                psmt.setString(1, usernames[i]);
                psmt.setString(2, password[i]);
                boolean wasThisRoundSuccessful = psmt.execute();
                wasThisMethodSuccessful = (wasThisMethodSuccessful && wasThisRoundSuccessful);
            }
            
            DatabaseForAdmin.closeConnection();
            wasThisMethodSuccessful = true;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return wasThisMethodSuccessful;
        }
        
    }
    
    public static boolean setupDatabaseOnFirstRun() {
        boolean wasThisMethodSuccessful = false;
        try {
            // check if we need to setup database
            DatabaseForAdmin.openConnection();
            DatabaseMetaData dbmd = DatabaseForAdmin.sharedConnection.getMetaData();
            ResultSet rs = dbmd.getTables(null, null, DatabaseForAdmin.TABLE_NAME_FOR_ADMIN, null);
            boolean needToSetupDatabase = false;
            if (!rs.next()) {
                needToSetupDatabase = true;
            }
            DatabaseForAdmin.closeConnection();
            
            // do further stuff if required
            if (needToSetupDatabase) {
                boolean createdTableSuccessfully = DatabaseForAdmin.createAdminTable();
                boolean createdDataSuccessfully = DatabaseForAdmin.setupDummyData();
                wasThisMethodSuccessful = (createdTableSuccessfully && createdDataSuccessfully);
            } else {
                wasThisMethodSuccessful = true;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            
        } finally {
            return wasThisMethodSuccessful;
        }
    }
    
    public static ArrayList<Admin> showAdminLogin() {
        ArrayList<Admin> preparedReturn = new ArrayList<Admin>();
        try {
            DatabaseForAdmin.openConnection();
            String sqlString = "SELECT * FROM " + DatabaseForAdmin.TABLE_NAME_FOR_ADMIN;
            Statement smt = sharedConnection.createStatement();
            ResultSet rs = smt.executeQuery(sqlString);
            while (rs.next()) {
                Admin newAdmin = new Admin(rs.getString("username"), rs.getString("password"));
                preparedReturn.add(newAdmin);
            }
            DatabaseForAdmin.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return preparedReturn;
        }
    }
    
    public static Admin fetchAdminByName(String username) {
        Admin preparedReturn = null;
        try {
            DatabaseForAdmin.openConnection();
            String sqlString = "SELECT * FROM " + DatabaseForAdmin.TABLE_NAME_FOR_ADMIN
                    + " WHERE username = ?";
            PreparedStatement psmt = sharedConnection.prepareStatement(sqlString);
            psmt.setString(1, username);
            ResultSet rs = psmt.executeQuery();
            while (rs.next()) {
                preparedReturn = new Admin(rs.getString("username"), rs.getString("password"));
            }
            DatabaseForAdmin.closeConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            return preparedReturn;
        }
    }
}
