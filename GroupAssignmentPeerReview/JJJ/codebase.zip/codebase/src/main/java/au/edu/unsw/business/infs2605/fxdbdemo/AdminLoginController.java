/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.fxdbdemo;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

/**
 *
 * @author Leo
 */
public class AdminLoginController {
    @FXML
    private Button SignUp1;
    
    @FXML
    private Button goBack;
    
    @FXML
    private Button loginScreenButton;
    
    @FXML
    private void switchToSignUp() throws IOException {
        App.setRoot("SignUp");
    }
    
    @FXML
    private void goBack() throws IOException {
        App.setRoot("InitiallScreen");
    }
    
    @FXML
    private void Login() throws IOException {
        App.setRoot("AdminDashboard");
    }
    
}
