/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.fxdbdemo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class Admin {
    private SimpleStringProperty username;
    private SimpleStringProperty password;

    public Admin(String username, String password) {
        this.username = new SimpleStringProperty(username);
        this.password = new SimpleStringProperty(password);
    }
    
    public StringProperty usernameProperty() {
        return username;
    }
    public StringProperty passwordProperty() {
        return username;
    }

    public String username() {
        return username.get();
    }

    public String password() {
        return password.get();
    }
    

    public void setUsername(String username) {
        this.username.set(username);
    }

    public void setPassword(String password) {
        this.password.set(password);
    }

    @Override
    public String toString() {
        return "Admin{" + "username=" + username + ", password=" + password + '}';
    }
}

