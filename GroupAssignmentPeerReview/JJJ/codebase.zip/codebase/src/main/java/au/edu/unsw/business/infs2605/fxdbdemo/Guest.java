/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.unsw.business.infs2605.fxdbdemo;
import java.util.Random;
/**
 *
 * @author Leo
 */
public class Guest extends User{
    private int guestid;
    private String name;
    private String email;
    private String accessCode;

    public Guest(int guestid, String name, String email, String accessCode) {
        this.guestid = guestid;
        this.name = name;
        this.email = email;
        this.accessCode = accessCode;
    }

    public int getGuestid() {
        return guestid;
    }

    public void setGuestid(int guestid) {
        this.guestid = guestid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAccessCode() {
        return accessCode;
    }

    public void setAccessCode(String accessCode) {
        this.accessCode = accessCode;
    }
    
    public static void integerRandomiser() {
               Random randomiser = new Random();
               int accessCode = 1000+randomiser.nextInt(8999);
      }

}
